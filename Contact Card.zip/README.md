Assignment for Coding Dojo's advanced jquery tutorial
